@extends('emails.email_template')
@section('content')
    {{ $rawMessage }}
@endsection
