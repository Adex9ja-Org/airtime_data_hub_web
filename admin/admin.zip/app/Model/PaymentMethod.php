<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 3/9/2020
 * Time: 6:57 PM
 */

namespace App\Model;


class PaymentMethod
{
    const Bank = "Bank";
    const Wallet = "Wallet";
    const Auto = "Auto";
    const Manual = "Manual";
    const Monify = "Monify";
}
