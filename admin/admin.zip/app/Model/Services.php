<?php


namespace App\Model;


class Services
{
    const Data_Purchase = "DATA_PUR_01";
    const Bill_Payment = "BILL_PAYMENT_001";
    const AirtimePurchase = "BUY_AIRTIME_001";
    const Airtime2Cash = "RE_SA_01";
}
