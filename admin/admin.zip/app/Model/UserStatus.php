<?php


namespace App\Model;


class UserStatus
{
    const active = 1;
    const banned = 0;
}
