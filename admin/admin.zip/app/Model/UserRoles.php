<?php


namespace App\Model;


class UserRoles
{
    const user = 'User';
    const admin = 'Admin';
    const agent = 'Agent';
}
